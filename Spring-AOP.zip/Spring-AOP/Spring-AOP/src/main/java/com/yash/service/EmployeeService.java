package com.yash.service;

public interface EmployeeService {

public void List(int id , String name);
}
